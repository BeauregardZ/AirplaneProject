package yxy.flyinggame.beans;

//敌人接口
public interface EnemyInterface {

	public int getScore();
}
